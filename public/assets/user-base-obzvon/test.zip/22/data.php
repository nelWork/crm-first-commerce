
    <?php file_put_contents("./info.json", $_POST["value"]);
    