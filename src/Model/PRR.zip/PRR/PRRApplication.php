<?php

namespace App\Model\PRR;

use App\Config\Config;
use App\Config\ConfigInterface;
use App\Database\Database;
use App\Database\DatabaseInterface;
use App\Model\Model;

class PRRApplication extends Model

{
    private DatabaseInterface $database;

    private ConfigInterface $config;

    private int $id = 0;
    private $date = null;
    private string $cityPrr = '';
    private string $cityClient = '';
    private string $contactPrr = '';
    private string $contactClient = '';
    private string $addressPrr = '';
    private string $addressClient = '';
    private string $phonePrr = '';
    private string $timePrr = '';
    private string $placePrr = '';
    private string $weightPrr = '';
    private string $numberLoadersPrr = '';
    private int $customerIdPrr = 0;
    private int $prrIdPrr = 0;
    private int $clientIdClient = 0;
    private string $natureCargoPrr = '';
    private string $specialConditionPrr = '';
    private string $termsPaymentPrr = '';
    private string $costPrr = '';
    private string $taxationTypePrr = '';
    private string $phoneClient = '';
    private string $timeClient = '';
    private string $placeClient = '';
    private string $weightClient = '';
    private string $numberLoadersClient = '';
    private int $customerIdClient = 0;
    private string $natureCargoClient = '';
    private string $specialConditionClient = '';
    private string $termsPaymentClient = '';
    private string $costClient = '';
    private string $taxationTypeClient = '';
    private int $idUser = 0;

    private string $applicationNumber = '';

    private int $idApplication = 0;

    private array $additionalExpensesList = [];
    private $dateLastUpdate = null;

    private string $datePrr = '';
    private string $dateClient = '';



    public array $fields = [
        'id', 'date', 'cityPrr', 'cityClient', 'contactPrr', 'contactClient',
        'addressPrr', 'addressClient', 'phonePrr', 'timePrr', 'placePrr', 'weightPrr',
        'numberLoadersPrr', 'customerIdPrr', 'prrIdPrr', 'clientIdClient', 'natureCargoPrr',
        'specialConditionPrr', 'termsPaymentPrr', 'costPrr', 'taxationTypePrr', 'phoneClient',
        'timeClient', 'placeClient', 'weightClient', 'numberLoadersClient', 'customerIdClient',
        'natureCargoClient', 'specialConditionClient', 'termsPaymentClient',
        'costClient', 'taxationTypeClient', 'idUser', 'dateLastUpdate','applicationNumber',
        'datePrr', 'dateClient', 'idApplication'
    ];

    public function __construct(array $data = [])
    {
        $this->config = new Config();
        $this->database = new Database($this->config);

        if (count($data) > 0) {
            $PRRApplication = $this->database->first("prr_application", $data);

            if(! $PRRApplication)
                return false;

            foreach ($PRRApplication as $key => $value) {
                $newKey = $this->sqlToPhpNameConvert($key);
                $this->$newKey = $value;
            }

            $this->additionalExpensesList = $this->database->select('additional_expenses_prr',['id_application' => $this->id]) ?? [];

        }
    }

    public function id()
    {
        return $this->id;
    }

    public function getAdditionalExpensesList()
    {
        return $this->additionalExpensesList;
    }

    public function edit(array $values): void
    {
        if(! empty($values['additionalExpenses']))
            $this->additionalExpensesList = [];
        foreach ($values as $key => $value) {
        if($key == 'additionalExpenses'){

            $data = json_decode($value, true);


            foreach ($data as $array) {
                $temp = $array;
                $temp['sum'] = str_replace(' ','',$array['sum']);


                $this->additionalExpensesList[] = $temp;


            }

        }
            $newKey = $this->sqlToPhpNameConvert($key);
//            var_dump([$newKey => $value]);
            $this->$newKey = $value;
        }
    }

    public function get(array $conditions = []): array|string
    {
        if (empty($conditions)) {

            $data = [];
            foreach ($this->fields as $field) {
                $data[$this->phpToSqlNameConvert($field)] = $this->$field;
            }
            return $data;
        }

        $returnedArray = [];
        try {
            foreach ($conditions as  $value) {
                $returnedArray[$this->phpToSqlNameConvert($value)] = $this->$value;
            }
        }
        catch (\Exception $e) {
            return $e->getMessage();
        }

        return $returnedArray;
    }

    private function getSetLastApplicationNumber(){
        $lastNumber = $this->database->first("document_flow")["application_prr_num"];

        $newNumber = $lastNumber + 1;

        if ($this->database->update("document_flow", ["application_prr_num" => $newNumber], ["id" => 1])){
            return $newNumber;
        }
        return null;
    }

    public function save(): bool
    {
        $newData = $this->get();

        if ($this->id > 0) {
            $stmt = $this->database->update("prr_application", $newData, ["id" => $this->id]);

            if (!empty($this->additionalExpensesList)) {
                $this->database->delete('additional_expenses_prr', ['id_application' => $this->id]);

                var_dump($this->additionalExpensesList);

                foreach ($this->additionalExpensesList as $additionalExpense) {
                    $this->database->insert('additional_expenses_prr',
                        [
                            'id_application' => $this->id,
                            'type_expenses' => $additionalExpense['type-expenses'],
                            'sum' => $additionalExpense['sum'],
                            'type_payment' => $additionalExpense['type-payment'],
                            'comment' => $additionalExpense['comment'],
                        ]
                    );
                }
            }

            return $stmt;
        }
        else{
            $this->date = date("Y-m-d H:i:s");
            $this->dateLastUpdate = date("Y-m-d H:i:s");
            $this->applicationNumber = $this->getSetLastApplicationNumber() .'-П';

            $newData = $this->get();

            $stmt = $this->database->insert("prr_application", $newData);


            if ($stmt) {
                $this->id = $stmt;

                $this->database->delete('additional_expenses_prr', ['id_application' => $this->id]);

                foreach ($this->additionalExpensesList as $additionalExpense) {
                    $this->database->insert('additional_expenses_prr',
                        [
                            'id_application' => $this->id,
                            'type_expenses' => $additionalExpense['type-expenses'],
                            'sum' => $additionalExpense['sum'],
                            'type_payment' => $additionalExpense['type-payment'],
                            'comment' => $additionalExpense['comment'],
                        ]
                    );
                }

                return true;
            }

            return $stmt;
        }
    }
}