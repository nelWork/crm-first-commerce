<?php
/** @var App\Model\User\User $userManager */
/** @var App\Model\Client\Client $client */
/** @var App\Model\PRR\PRRCompany $prrCompany */
/** @var App\Model\PRR\PRRApplication $prrApplication */
$prrApplicationData = $prrApplication->get();
?>
<div class="side-block-dop-info">
    <div class="dop-info-item">
        <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-1"
             aria-expanded="false" aria-controls="collapse-carrier-1">
            <span>Реквизиты клиента</span>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </div>
        </div>
        <div class="collapse dop-info-collapse" id="collapse-carrier-1">
            <div class="mb-4">
                <span class="side-tab-span">ИНН</span>
                <span class="side-main-span"><?php echo $client->get()['inn']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Юр. адрес</span>
                <span class="side-main-span"><?php echo $client->get()['legal_address']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Контактное лицо</span>
                <span class="side-main-span"><?php echo $client->get()['phone']; ?></span>
            </div>
        </div>
    </div>

    <div class="dop-info-item">
        <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-2"
             aria-expanded="false" aria-controls="collapse-carrier-2">
            <span>Реквизиты компании ПРР</span>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </div>
        </div>
        <div class="collapse dop-info-collapse" id="collapse-carrier-2">
            <div class="mb-4">
                <span class="side-tab-span">ИНН</span>
                <span class="side-main-span"><?php echo $prrCompany->get()['name']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Почтовый адрес</span>
                <span class="side-main-span"><?php echo $prrCompany->get()['name']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Контактное лицо</span>
                <span class="side-main-span"></span>
                <span class="side-tab-span"></span>
            </div>
        </div>
    </div>


    <div class="dop-info-item">
        <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-3"
             aria-expanded="false" aria-controls="collapse-carrier-3">
            <span>Место разгрузки</span>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </div>
        </div>
        <div class="collapse dop-info-collapse" id="collapse-carrier-3">
            <div class="mb-4">
                <span class="side-tab-span">Город</span>
                <span class="side-main-span"><?php echo $prrApplicationData['city_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Адрес</span>
                <span class="side-main-span"><?php echo $prrApplicationData['address_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Дата</span>
                <span class="side-main-span"><?php echo date('d.m.Y', strtotime($prrApplicationData['date_prr'])); ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Время</span>
                <span class="side-main-span"><?php echo $prrApplicationData['time_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Контактное лицо</span>
                <span class="side-main-span"><?php echo $prrApplicationData['contact_prr']; ?></span>
            </div>
            <div class="mt-4">
                <span class="side-tab-span">Стоимость</span>
                <span class="side-main-span">
                    <?php echo number_format($prrApplicationData['cost_prr'],0 ,'.', ' '); ?> ₽
                </span>
            </div>
        </div>
    </div>

    <div class="dop-info-item">
        <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-4"
             aria-expanded="false" aria-controls="collapse-carrier-4">
            <span>Детали разгрузки</span>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </div>
        </div>
        <div class="collapse dop-info-collapse" id="collapse-carrier-4">
            <div class="mb-4">
                <span class="side-tab-span">Характер груза</span>
                <span class="side-main-span"><?php echo $prrApplicationData['nature_cargo_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Мест</span>
                <span class="side-main-span"><?php echo $prrApplicationData['place_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Вес</span>
                <span class="side-main-span"><?php echo $prrApplicationData['weight_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Кол-во грузчиков</span>
                <span class="side-main-span"><?php echo $prrApplicationData['number_loaders_prr']; ?></span>
            </div>
            <div class="mb-4">
                <span class="side-tab-span">Доп. информация</span>
                <span class="side-main-span"><?php echo $prrApplicationData['special_condition_prr']; ?></span>
            </div>
        </div>
    </div>


    <div class="dop-info-item">
        <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-8"
             aria-expanded="false" aria-controls="collapse-carrier-8">
            <span>Дополнительные затраты</span>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                    <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                </svg>
            </div>
        </div>
        <div class="collapse dop-info-collapse" id="collapse-carrier-8">
            <?php
            $cnt = 1;
            foreach ($prrApplication->getAdditionalExpensesList() as $expense):
                ?>
                <div class="w-100 dop-info-collapse-header" data-bs-toggle="collapse" data-bs-target="#collapse-carrier-8-<?php echo $cnt; ?>"
                     aria-expanded="false" aria-controls="collapse-carrier-8-<?php echo $cnt; ?>">
                    <span>Дополнительные затраты <?php echo $cnt; ?></span>
                    <div class="icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
                            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4z"/>
                        </svg>
                    </div>
                </div>
                <div class="collapse dop-info-collapse" id="collapse-carrier-8-<?php echo $cnt; ?>">
                    <div class="mb-4">
                        <span class="side-tab-span">Вид затрат</span>
                        <span class="side-main-span">
                        <?php echo $expense['type_expenses']; ?>
                        </span>
                    </div>
                    <div class="mb-4">
                        <span class="side-tab-span">Сумма</span>
                        <span class="side-main-span">
                            <?php echo number_format($expense['sum'],0 ,'.', ' '); ?> ₽
                        </span>
                    </div>
                    <div class="mb-4">
                        <span class="side-tab-span">Вид налогообложения</span>
                        <span class="side-main-span">
                        <?php echo $expense['type_payment']; ?>
                    </span>
                    </div>
                    <div class="">
                        <span class="side-tab-span">Комментарии</span>
                        <span class="side-main-span">
                        <?php echo $expense['comment']; ?>
                    </span>
                    </div>
                </div>

                <?php $cnt++;
            endforeach; ?>
        </div>
    </div>

</div>