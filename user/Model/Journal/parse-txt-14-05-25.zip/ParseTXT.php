<?php

namespace App\User\Model\Journal;

use App\User\Model\Model;

class ParseTXT extends Model
{
    private string $pathDocTemplate = APP_PATH .'/public/doc/journal/';

    private $filePath;

    public function __construct($filePath) {
        $this->filePath = $filePath;
    }

    public function parseDocuments() {
        // Читаем содержимое файла
        $content = file_get_contents($this->filePath);

        if ($content === false) {
            die("Ошибка при чтении файла");
        }

        // Устанавливаем кодировку в UTF-8, если необходимо
        $content = mb_convert_encoding($content, 'UTF-8', 'Windows-1251');

        // Разбиваем файл на секции по шаблону
        preg_match_all('/СекцияДокумент=Платежное поручение(.*?)КонецДокумента/su', $content, $matches);

        return array_map('trim', $matches[1]); // Возвращаем массив документов
    }

    public function parseKeyValue($document) {
        $lines = explode("\n", $document);
        $assocArray = [];

        foreach ($lines as $line) {
            $line = trim($line);
            if (strpos($line, '=') !== false) {
                list($key, $value) = explode('=', $line, 2);
                $assocArray[trim($key)] = trim($value);
            }
        }

        // Проверяем ключ "НазначениеПлатежа" и ищем текст по формату
        if (isset($assocArray['НазначениеПлатежа'])) {
            $assocArray['Заявка'] = $this->extractRequestNumber($assocArray['НазначениеПлатежа']);

            // Если заявка не найдена, ищем счета
            if (!$assocArray['Заявка']) {
                $assocArray['Счета'] = $this->extractAccounts($assocArray['НазначениеПлатежа']);
            }
        }

        return $assocArray;
    }

    private function extractRequestNumber($text) {
        // Обновленное регулярное выражение для учёта всех форматов
        if (preg_match('/Заявк[а,и]?\s*№?\s*"?\s*(\d+)\s*"*/u', $text, $matches)) {
            return isset($matches[1]) ? $matches[1] : null; // Возвращаем найденное число заявки
        }
        return null; // Если не найдено, возвращаем null
    }

    private function extractAccounts($text) {
        if (stripos($text, 'Аванс') !== false OR stripos($text, 'Возврат подотчетных средств') !== false) {
            return null; // Пропускаем, если есть слово "Аванс"
        }

        // Убираем годы (2023, 2024, 2025)
        $text = preg_replace('/\b(2023|2024|2025)\b/u', '', $text);

        // Убираем упоминания НДС (например, "НДС (20%)", "НДС (10%)", "НДС (18%)")
        $text = preg_replace('/НДС\s*\(.*?\)/ui', '', $text);

        // Убираем "г" (год) после даты, если оно мешает
        $text = preg_replace('/\b(\d{1,2}\.\d{1,2}\.\d{4})г\b/u', '$1', $text);

        // Игнорируем договоры вида "ДОГОВОР №10/24"
        $text = preg_replace('/ДОГОВОР\s*№?\s*\d+\/\d+/ui', '', $text);

        // Игнорируем форматы вида "##ПС00-П000775/25.03.2025##"
        $text = preg_replace('/##.*?##/u', '', $text);

        // Заменяем "\" на "/"
        $text = str_replace('\\', '/', $text);

        // 1. Ищем счета с припиской (например, "№ 2/число" или "2/число") и убираем приписку
        preg_match_all('/(?:№\s*)?\d+\/(\d+)/u', $text, $matches);
        if (!empty($matches[1])) {
            return $matches[1]; // Оставляем только число после "/"
        }

        // 2. Если не нашли, ищем счета без приписки (например, "№ число")
        preg_match_all('/№\s*(\d+)/u', $text, $matches);
        if (!empty($matches[1])) {
            return $matches[1]; // Возвращаем массив найденных номеров счетов без приписки
        }

        // 3. Если не нашли, ищем счета в формате "№число" или "№ число"
        preg_match_all('/№\s*"*(\d+)"/u', $text, $matches);
        if (!empty($matches[1])) {
            return $matches[1]; // Возвращаем массив найденных счетов в этом формате
        }

        // 4. Если не нашли, ищем по новому формату: "число" от / "число" ОТ
        preg_match_all('/(\d+)\s+[О,о][Т,т]/u', $text, $matches);
        if (!empty($matches[1])) {
            return $matches[1]; // Возвращаем массив найденных счетов по формату "число от"
        }

        return null; // Если ничего не нашли, возвращаем null
    }



    public function getParsedDocuments() {
        $documents = $this->parseDocuments();
        return array_map([$this, 'parseKeyValue'], $documents);
    }



}